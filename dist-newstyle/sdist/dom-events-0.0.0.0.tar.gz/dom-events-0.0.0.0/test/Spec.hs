import Data.DOM.Event

main :: IO ()
main = putStrLn "Import successful - as there are no functions, this just tests the compilation."
